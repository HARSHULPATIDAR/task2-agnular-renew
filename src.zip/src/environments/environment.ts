export const environment = {
  production: false,
  endpoint: 'https://scrapyard-api.aarchik.com/',
  projectURL: 'https://scrapyards.vercel.app/',
  // endpoint: 'http://localhost:2021/',
  // projectURL: 'http://localhost:4200/',
  googleAPI: 'https://maps.googleapis.com/maps/api/',
  encryptKey: '672473006935',
  encryptIV: '672476046983',
};
