import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FormFieldService, FormField } from '../../_services/form-field.service';

@Component({
  selector: 'app-form-builder',
  templateUrl: './form-builder.component.html',
  styleUrls: ['./form-builder.component.scss']
})
export class FormBuilderComponent {
  fieldForm: FormGroup;

  constructor(private fb: FormBuilder, private formFieldService: FormFieldService) {
    this.fieldForm = this.fb.group({
      type: ['text'],
      label: [''],
      placeholder: [''],
      required: [false],
      options: ['']
    });
  }

  addField() {
    const newField: FormField = {
      type: this.fieldForm.value.type,
      label: this.fieldForm.value.label,
      placeholder: this.fieldForm.value.placeholder,
      required: this.fieldForm.value.required,
      options: this.fieldForm.value.type === 'dropdown' ? this.fieldForm.value.options.split(',') : []
    };

    this.formFieldService.addField(newField);
    this.fieldForm.reset({ type: 'text', required: false });
  }
}
