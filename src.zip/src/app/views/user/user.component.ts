import { Component, OnInit } from '@angular/core';
import { Actions, MenuName, Pagination, RouteNames } from '../../_constants';
import { CommonService, UserService } from '../../_services';
import { TableCols } from '../../_interfaces';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {
  tableData: any = [];
  tableColumns: any = TableCols;
  pageConfig = JSON.parse(JSON.stringify(Pagination));
  keyword: string = '';
  pageTitle: string = MenuName.USER;

  constructor(
    private router: Router,
    private userService: UserService,
    private commonService: CommonService,
  ) { }

  ngOnInit(): void {
    this.getUser();
  }


  getUser(): void {
    const req = {
      ...this.pageConfig,
      keyword: this.keyword
    };
    this.userService.getUser(req).subscribe((res: any) => {
      if (res.success) {
        this.tableData = res.data;
      } else {
        this.commonService.toaster(res);
      }
      this.commonService.setTableData.next({ items: res });
      this.commonService.emitValueForSpinner();
    });
  }

  /**
   * On action click to Add, Edit, Delete Or View data
   * @param event action object
   */
  onAction(event: any) {
    switch (event.flag) {
      case Actions.ADD:
        this.router.navigate([RouteNames.USER_ADD]);
        break;
      case Actions.UPDATE:
        this.router.navigate([RouteNames.USER_UPDATE + event.item._id]);
        break;
      case Actions.DELETE:
        this.deleteRecord(event.selectedRecords);
        break;
    }
  }

  /**
   * Delete record
   * @param item record id
   */
  deleteRecord(item: any) {
    this.userService.deleteUser({ _id: item }).subscribe((res: any) => {
      if (res.success) {
        if (this.tableData.length === item.length && this.pageConfig.currentPage != 1) {
          this.pageConfig.currentPage -= 1;
        }
        this.getUser();
      }
      this.commonService.toaster(res);
    });
  }

  /**
   * On page change get new records
   * @param event page config
   */
  onPageChange(event: any) {
    this.pageConfig = event;
    this.getUser();
  }

  /**
   * On search item
   * @param event search text
   */
  onSearch(event: any) {
    this.pageConfig = JSON.parse(JSON.stringify(Pagination));
    this.keyword = event;
    this.getUser();
  }
}
