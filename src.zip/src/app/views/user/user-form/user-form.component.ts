import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MyErrorStateMatcher } from '../../../helpers';
import { CommonService, UserService } from '../../../_services';
import { Actions, FAICONS, Menus, Regex } from '../../../_constants';
import { Roles } from '../../../_interfaces';

@Component({
  selector: 'app-user-form',
  templateUrl: './user-form.component.html',
  styleUrls: ['./user-form.component.scss']
})
export class UserFormComponent implements OnInit {
  userForm: FormGroup | any;
  matcher = new MyErrorStateMatcher();
  pageTitle: string = Actions.ADD;
  roles: any = Roles;
  menus: any = JSON.parse(JSON.stringify(Menus));
  selectedMenus: any = [];
  userDetails: any = {};
  userId: any = this.activatedRoute.snapshot.params['userId'];
  hidePassword = true;
  faIcon: any = FAICONS;

  constructor(
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    public commonService: CommonService,
    private userService: UserService,
  ) { }

  ngOnInit(): void {
    this.formInitialization();
    if (this.userId) {
      this.pageTitle = Actions.UPDATE;
      this.getUserById();
   
    }
  }

  /**
   * Get user by id
   */
  getUserById() {
    this.userService.getUser({ _id: this.userId }).subscribe((res: any) => {
      if (res.success) {
        this.userDetails = res.data[0];
        this.selectedMenus = this.userDetails.menu_items || [];
        if (this.selectedMenus.length > 0) {
          this.selectedMenus.forEach((ele: any) => {
            this.menus.forEach((val: any) => {
              if (ele.slug === val.slug) {
                val.is_selected = true;
                if (ele.subMenu && val.subMenu) {
                  ele.subMenu.forEach((_e: any) => {
                    val.subMenu.forEach((_v: any) => {
                      if (_e.slug === _v.slug) {
                        _v.is_selected = true;
                      }
                    })
                  });
                }
              }
            });
          });
        }
        this.formInitialization();
      }
      this.commonService.emitValueForSpinner();
    });
  }

  togglePasswordVisibility() {
    this.hidePassword = !this.hidePassword;
  }

  /**
   * form initialization
   * @param data admin details
   */
  formInitialization() {
    this.userForm = this.formBuilder.group({
      name: [this.userDetails.name || '', Validators.required],
      email: [this.userDetails.email || '', Validators.compose([Validators.required, Validators.pattern(Regex.email)])],
      phone_no: [this.userDetails.phone_no || '', Validators.required],
      password: [""],
      role: [this.userDetails.role || '', Validators.required],
      menu_items: [this.userDetails.menu_items],
    });

    if (!this.userId) {
      this.userForm.get('password').setValidators(Validators.required)
      this.userForm.get('password').updateValueAndValidity();
    }
  }

  get userFG() {
    return this.userForm.controls;
  }

  /**
   * Select menu to give access of that menu
   * @param event true / false
   * @param menu menu details
   * @param subMenu sub menu details
   */
  selectMenu(event: any, menu: any, subMenu?: any) {
    if (menu.subMenu && subMenu) {
      const index = this.selectedMenus.findIndex((item: any) => item.slug === menu.slug);
      if (event.checked) {
        if (index >= 0) {
          let items: any = this.selectedMenus.filter((item: any, key: number) => index === key)[0];
          items.subMenu = [...items.subMenu, { slug: subMenu.slug }];
          this.selectedMenus[index] = items;
        } else {
          this.selectedMenus.push({
            slug: menu.slug,
            subMenu: [{ slug: subMenu.slug }]
          });
        }
      } else {
        let items: any = this.selectedMenus.filter((item: any, key: number) => index === key)[0];
        items.subMenu = items.subMenu.filter((item: any) => item.slug !== subMenu.slug);
        this.selectedMenus[index] = items;
        if (!items.subMenu || items.subMenu.length === 0) {
          this.selectedMenus.splice(index, 1);
        }
      }
    } else if (!menu.subMenu && !subMenu) {
      if (event.checked) {
        this.selectedMenus.push({ slug: menu.slug });
      } else {
        this.selectedMenus = this.selectedMenus.filter((ele: any) => ele.slug !== menu.slug);
      }
    }
  }

  /**
  * On submit to save data
  */
  onSubmit() {
    if (this.userId) {
      this.userForm.value._id = this.userId;
    }
    this.userForm.value.menu_items = this.selectedMenus;
    this.userService.saveUser(this.userForm.value).subscribe((res: any) => {
      if (res.success) {
        this.commonService.goBack();
      }
      this.commonService.emitValueForSpinner();
      this.commonService.toaster(res);
    });
  }
}
