import { Injectable } from '@angular/core';
import { DatePipe } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { BehaviorSubject } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class CommonService {
    public isHideSpinner = new BehaviorSubject({ is_hide_spinner: true });
    public setTableData = new BehaviorSubject({});
    isCheckAll = false;
    selectedRecords: any = [];

    constructor(
        private datePipe: DatePipe,
        private toastr: ToastrService,
    ) { }

    /**
     * Multi Select record
     * @param event change event object
     * @param data res data
     */
    multiSelect(event: any, data: any) {
        this.isCheckAll = false;
        this.selectedRecords = [];
        data.forEach((items: any) => {
            if (event.source.name === 'isCheckAll') {
                items.is_checked = event.source.checked;
            } else {
                if (event.source.value == items._id) {
                    items.is_checked = event.source.checked;
                }
            }
            if (items.is_checked) {
                this.selectedRecords.push(items._id);
            }
        });
        this.isCheckAll = data.length === this.selectedRecords.length;
        return data;
    }

    /**
     * Go back to previous page
     */
    goBack() {
        history.back();
    }

    /**
     * Show toast message
     * @param res res data
     */
    toaster(res: any) {
        if (res?.success) {
            this.toastr.success(res.message);
        } else {
            this.toastr.error(res.message);
        }
    }

    /**
     * Emit value for spinner
     * Default value is true
     * @param value boolean value
     */
    emitValueForSpinner(value: boolean = true) {
        this.isHideSpinner.next({ is_hide_spinner: value });
    }

    /**
     * Change date format 
     * @param date date
     * @param format  date format
     */
    changeDateFormat(format = 'yyyy-MM-dd', date = new Date()) {
        return this.datePipe.transform(date, format)
    }
}