import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export interface FormField {
  type: string;
  label: string;
  placeholder: string;
  required: boolean;
  options?: string[];
}

@Injectable({
  providedIn: 'root'
})
export class FormFieldService {
  private fieldsSubject = new BehaviorSubject<FormField[]>([]);
  fields$ = this.fieldsSubject.asObservable();

  addField(field: FormField) {
    const fields = this.fieldsSubject.value;
    this.fieldsSubject.next([...fields, field]);
  }
}
