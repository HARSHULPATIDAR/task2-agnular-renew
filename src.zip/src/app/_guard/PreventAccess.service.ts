import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { LOCAL_KEY, RouteNames } from '../_constants';
import { getLocalStorage, removeLocalStorageItems } from '../helpers';

@Injectable({
    providedIn: 'root',
})

export class PreventAccess implements CanActivate {

    constructor(
        private router: Router
    ) { }

    canActivate() {
        const token = getLocalStorage(LOCAL_KEY.TOKEN);
        if (!token) {
            removeLocalStorageItems();
            return true;
        } else {
            this.router.navigate([RouteNames.DASHBOARD]);
            return false;
        }
    }
}
