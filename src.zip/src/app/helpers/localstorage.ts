import { environment } from "src/environments/environment";
import { LOCAL_KEY, RouteNames } from "../_constants";
import * as CryptoJS from 'crypto-js';

/**
 * Set data in local storage
 * @param key key
 * @param value value
 */
export function setLocalStorage(key: string, value: any) {
    localStorage.setItem(key, encryptUsingAES256(value));
}

/**
 * Get data from local storage
 * @param key key
 */
export function getLocalStorage(key: string) {
    if (!localStorage.getItem(key)) {
        return;
    }
    let encryptedData = localStorage.getItem(key);
    let decryptedData = decryptUsingAES256(encryptedData);
    decryptedData = JSON.parse(decryptedData);
    return decryptedData;
}

/**
 * Encrypt data
 * @param value value
 */
export function encryptUsingAES256(value: any) {
    let originalData = JSON.stringify(value);
    let _key = CryptoJS.enc.Utf8.parse(environment.encryptKey);
    let _iv = CryptoJS.enc.Utf8.parse(environment.encryptIV);

    let encrypted: any;
    try {
        encrypted = CryptoJS.AES.encrypt(originalData, _key, {
            keySize: 16,
            iv: _iv,
            mode: CryptoJS.mode.ECB,
            padding: CryptoJS.pad.Pkcs7
        }).toString();
    } catch (error) {
        logoutIfEncDecIsNotValid();
    }
    return encrypted;
}

/**
 * Decrypt data
 * @param encryptedData value
 */
export function decryptUsingAES256(encryptedData: any) {
    let _key = CryptoJS.enc.Utf8.parse(environment.encryptKey);
    let _iv = CryptoJS.enc.Utf8.parse(environment.encryptIV);
    let decrypted: any;
    try {
        decrypted = CryptoJS.AES.decrypt(encryptedData, _key, {
            keySize: 16,
            iv: _iv,
            mode: CryptoJS.mode.ECB,
            padding: CryptoJS.pad.Pkcs7
        }).toString(CryptoJS.enc.Utf8);
    } catch (error) {
        logoutIfEncDecIsNotValid();
    }
    return decrypted;
}

/**
 * Remove local storage
 */
export function removeLocalStorageItems() {
    localStorage.removeItem(LOCAL_KEY.USER_DETAILS);
    localStorage.removeItem(LOCAL_KEY.TOKEN);
}

/**
     * If encryption and decryption is not valid then logout the user
     */
export function logoutIfEncDecIsNotValid() {
    localStorage.clear();
    location.href = RouteNames.LOGIN;
}