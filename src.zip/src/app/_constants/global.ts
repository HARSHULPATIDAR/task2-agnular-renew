export const SCRAPYARD = 'https://chinmayimpex.com/';


export enum Assets {
    LOGO = '../../../../assets/images/logo.png',

};

export enum FAICONS {
    HOME = 'fa fa-home',
    FOLDER = 'fa fa-folder',
    GLOBE = 'fa fa-globe',
    FORT = 'fab fa-fort-awesome',
    PLUS = 'fa fa-plus',
    DELETE = 'fa fa-trash',
    PENCIL = 'fas fa-pencil-alt',
    WARNING = 'fa fa-exclamation-circle',
    EYE = 'fa fa-eye',
    USER = 'fa fa-users',
    CLOSE = 'fa fa-times',
    CHECK = 'fa fa-check',
    LIST = 'fa fa-list-alt',
    CLOSE_EYE = 'fa fa-eye-slash',

   
};

export enum Actions {
    ADD = 'Add',
    UPDATE = 'Update',
    DELETE = 'Delete',
    VIEW = 'View',
    LIST = 'List',
}

export const Regex = {
    alphabets: /^[a-zA-Z \-\']+$/,
    mobileNo: /[0-9]{10}/,
    numbersonly: /^([0-9]*)$/,
    decimal: /^[1-9][1-9]*[.]?[0-9]{0,2}$/,
    email: /(?:[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-zA-Z0-9-]*[a-zA-Z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])/
};

export const DeleteMsg = {
    width: '450px',
    height: '405px',
    data: {
        title: 'Are you sure want to delete it?',
        message: 'It will delete permanently!',
        okBtnLabel: 'Yes',
        cancelBtnLabel: 'No',
    }
};



export const Pagination = { currentPage: 1, pageSize: 10, totalItems: 0 };

export const DefaultPageSize = [10, 20, 30];

export const NoDataFound = 'No Data Found';

export enum LOCAL_KEY {
    USER_DETAILS = 'USER_DETAILS',
    TOKEN = 'TOKEN',
}

export enum StorageKey {
    USER_DETAILS = 'USER_DETAILS',
    TOKEN = 'TOKEN',
    ADMIN_INFO = 'ADMIN_INFO',
    ADMIN_TOKEN = 'ADMIN_TOKEN',
};
