import { NgModule } from '@angular/core';
import { UserRolePipe } from './role.pipe';

@NgModule({
    declarations: [
        UserRolePipe
    ],
    exports: [
        UserRolePipe
    ]
})
export class PipeModule { }
